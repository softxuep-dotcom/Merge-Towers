import {
  W, H, MAX_LV, ELEMENTS, ENEMY_TYPES, BASE_HP, LEAK_BOSS, LEAK_NORMAL,
  PHASES, phaseFor, towerCost, waveHp, waveCount, spawnFloor, DIAMOND,
  MERGE_SURGE, SLOT_AFFIXES, ELITE, TOWER_BRANCHES,
} from '../config.js';
import { Enemy, Path } from '../classes/Enemy.js';
import { Tower } from '../classes/Tower.js';
import { makeButton, toast } from '../ui.js';
import { Sfx, setMuted, isMuted } from '../audio.js';
import { Poki } from '../poki.js';
import { writeSave, tier, unlockedElements } from '../save.js';

// 地面路径（对齐 assets/maps/forest-grid-bg.png 中的石板路，坐标经像素采样校准）
const PATH_PTS = [
  { x: 108, y: -40 }, { x: 128, y: 120 }, { x: 150, y: 250 }, { x: 185, y: 316 },
  { x: 540, y: 316 }, { x: 598, y: 370 }, { x: 598, y: 460 }, { x: 540, y: 516 },
  { x: 190, y: 516 }, { x: 130, y: 570 }, { x: 130, y: 670 }, { x: 190, y: 732 },
  { x: 540, y: 732 }, { x: 598, y: 790 }, { x: 598, y: 870 }, { x: 545, y: 935 },
  { x: 400, y: 945 }, { x: 355, y: 990 }, { x: 370, y: 1035 }, { x: 440, y: 1050 },
];
// 飞行兵直线航道（GDD §4.2：穿过中央塔位射程）
const FLY_PTS = [{ x: -50, y: 400 }, { x: 440, y: 1040 }];
const SLOT_XS = [145, 251, 360, 465, 572];
const SLOT_YS = [400, 608, 824];
const TYPE_ICON = { slime: '🟣', runner: '💨', tank: '🛡️', flyer: '🐝', splitter: '🟠', boss: '💀', mini: '·' };
const TYPE_CN = { slime: '小兵', runner: '疾行者', tank: '铁盾兵', flyer: '飞行兵', splitter: '分裂怪', boss: 'Boss', mini: '小怪' };
const ELITE_ICON = { shield: '🛡', haste: '🌀', split: '✹' };

export class GameScene extends Phaser.Scene {
  constructor() { super('Game'); }

  create() {
    const S = this.S = this.registry.get('save');
    // ---- 局内状态 ----
    this.gold = Math.round((40 + 20 * tier(S, 'startGold')) * (S.coupon ? 1.5 : 1));
    if (S.coupon) { S.coupon = false; writeSave(S); }
    this.maxBase = BASE_HP + 2 * tier(S, 'baseArmor');
    this.baseHp = this.maxBase;
    this.wave = 1;
    this.bought = 0;
    this.kills = 0;
    this.diamondsRun = 0;
    this.highestLv = 1;
    this.revived = false;
    this.lastStandUsed = false;
    this.lastStandActive = false;
    this.lastStandT = 0;
    this.lastStandLeaked = false;
    this.lastStandOverlay = null;
    this.lastStandText = null;
    this.deathWave = 0;
    this.adGifts = 0;
    this.speedMult = 1;
    this.slowmoT = 0;
    this.atkBuffT = 0;
    this.atkBuffMult = 1.3;
    this.evolutionChoiceOpen = false;
    this.evolutionLayer = null;
    this.evolutionPrevTimeScale = null;
    this.evolutionPrevTweenScale = null;
    this.holyHealThisWave = 0;
    this.waveGoldMult = 1;
    this.resonanceGoldMult = 1;
    this.resonanceStacks = 0;
    this.resonanceDeadline = 0;
    this.resonanceRing = null;
    this.waveState = 'idle'; // prep | active
    this.spawnLeft = 0;
    this.dying = false;
    this.over = false;
    this.enemies = [];
    this.towers = [];
    this.burnZones = [];
    this.leakStats = {};
    this.dmgCount = 0;
    this.coinCount = 0;
    this.lastKillSfx = 0;

    this.path = new Path(PATH_PTS);
    this.flyPath = new Path(FLY_PTS);

    this.buildField();
    this.buildUI();
    this.setupDrag();
    this.presetTowers();

    // 自动化（局外解锁）
    this.time.addEvent({ delay: 600, loop: true, callback: () => this.autoBuyTick() });
    this.time.addEvent({ delay: 800, loop: true, callback: () => this.autoMergeTick() });

    Poki.gameplayStart();
    this.startPrep();
  }

  // ================= 场景搭建 =================
  buildField() {
    const ph = phaseFor(1);
    this.hasBg = this.textures.exists('map_bg');

    if (this.hasBg) {
      // 森林手绘背景：平台/路径/城堡已在图中，逻辑坐标对齐即可
      this.add.image(W / 2, H / 2, 'map_bg').setDepth(-20);
      // 阶段色调改为半透明叠色层（白天 alpha=0）
      this.phaseOverlay = this.add.rectangle(W / 2, H / 2, W, H, ph.bg, 0).setDepth(-18);
    } else {
      this.bgAll = this.add.rectangle(W / 2, H / 2, W, H, ph.bg).setDepth(-20);
      this.ground = this.add.rectangle(W / 2, 490, 704, 940, ph.ground).setDepth(-19);
      const g = this.add.graphics().setDepth(-15);
      g.lineStyle(58, 0x2a2d40, 1);
      g.strokePoints(PATH_PTS.map(p => new Phaser.Math.Vector2(p.x, p.y)), false);
      PATH_PTS.slice(1, -1).forEach(p => { g.fillStyle(0x2a2d40, 1); g.fillCircle(p.x, p.y, 29); });
      g.lineStyle(46, 0x3a3e58, 1);
      g.strokePoints(PATH_PTS.map(p => new Phaser.Math.Vector2(p.x, p.y)), false);
      PATH_PTS.slice(1, -1).forEach(p => { g.fillStyle(0x3a3e58, 1); g.fillCircle(p.x, p.y, 23); });
      this.add.image(560, 1000, 'base').setDepth(1040);
    }

    // 飞行航道（虚线示意，两种模式都画）
    const fg = this.add.graphics().setDepth(-14);
    fg.lineStyle(2, 0x7fe7e0, this.hasBg ? 0.18 : 0.25);
    const fa = FLY_PTS[0], fb = FLY_PTS[1];
    for (let t = 0; t < 1; t += 0.05) {
      fg.lineBetween(fa.x + (fb.x - fa.x) * t, fa.y + (fb.y - fa.y) * t,
        fa.x + (fb.x - fa.x) * (t + 0.025), fa.y + (fb.y - fa.y) * (t + 0.025));
    }

    // 塔位（背景图已画好平台 → 只建逻辑格 + 拖拽时的高亮环）
    this.slots = [];
    this.slotRings = [];
    for (const y of SLOT_YS) for (const x of SLOT_XS) {
      if (!this.hasBg) this.add.image(x, y, 'slot').setDepth(-10);
      const ring = this.add.circle(x, y, 46, 0xffe97a, 0).setStrokeStyle(3, 0xffe97a, 0).setDepth(-9);
      this.slots.push({ x, y, tower: null, ring });
      this.slotRings.push(ring);
    }
    this.assignSlotAffixes();

    // 红色警示边缘（漏怪反馈）
    this.vignette = this.add.rectangle(W / 2, H / 2, W, H, 0xff2222, 0).setDepth(2900);
    // 白闪（最高级合成）
    this.flash = this.add.rectangle(W / 2, H / 2, W, H, 0xffffff, 0).setDepth(2950);
  }

  // 拖拽时高亮所有空塔位
  showFreeSlots(on) {
    for (const s of this.slots) {
      s.ring.setStrokeStyle(3, 0xffe97a, on && !s.tower ? 0.7 : 0);
    }
  }

  assignSlotAffixes() {
    const keys = Object.keys(SLOT_AFFIXES);
    const count = Phaser.Math.Between(2, 3);
    const picked = Phaser.Utils.Array.Shuffle(this.slots.slice()).slice(0, count);
    picked.forEach((slot, i) => {
      const affix = SLOT_AFFIXES[keys[i % keys.length]];
      slot.affix = affix;

      const glow = this.add.image(slot.x, slot.y + 2, 'glow')
        .setTint(affix.color)
        .setAlpha(0.42)
        .setScale(1.22)
        .setDepth(-8);
      const icon = this.uiText(slot.x + 30, slot.y - 18, affix.icon, 20, this.hexColor(affix.color))
        .setOrigin(0.5)
        .setDepth(-7);
      icon.setStroke('#1a1d2e', 4);
      const pulse = this.add.circle(slot.x, slot.y, 40, affix.color, 0)
        .setStrokeStyle(2, affix.color, 0.34)
        .setDepth(-7);
      this.tweens.add({ targets: glow, alpha: 0.22, scale: 1.4, duration: 1300, yoyo: true, repeat: -1, ease: 'Sine.InOut' });
      this.tweens.add({ targets: pulse, scale: 1.12, alpha: 0.26, duration: 1100, yoyo: true, repeat: -1, ease: 'Sine.InOut' });
      slot.affixFx = [glow, icon, pulse];
    });
  }

  // 开发用：叠加路径与塔位标记校准坐标（发布前移除调用即可）
  debugMap() {
    const g = this.add.graphics().setDepth(3500);
    g.lineStyle(4, 0xff00ff, 0.8);
    g.strokePoints(PATH_PTS.map(p => new Phaser.Math.Vector2(p.x, p.y)), false);
    g.lineStyle(2, 0x00ffff, 0.8);
    g.strokePoints(FLY_PTS.map(p => new Phaser.Math.Vector2(p.x, p.y)), false);
    for (const s of this.slots) {
      g.lineStyle(3, 0xffff00, 0.9);
      g.strokeCircle(s.x, s.y, 40);
      g.lineBetween(s.x - 10, s.y, s.x + 10, s.y);
      g.lineBetween(s.x, s.y - 10, s.x, s.y + 10);
    }
    this.time.delayedCall(8000, () => g.destroy());
    return 'debug overlay 8s';
  }

  buildUI() {
    // 顶部状态栏
    this.add.rectangle(W / 2, 30, W, 60, 0x161825, 0.9).setDepth(1000);
    this.waveText = this.uiText(20, 30, '', 26, '#ffffff').setOrigin(0, 0.5);
    this.heartText = this.uiText(180, 30, '', 24, '#ff7a7a').setOrigin(0, 0.5);
    this.add.image(332, 30, 'coin').setDepth(1001).setScale(1.2);
    this.goldText = this.uiText(350, 30, '0', 26, '#ffd34e').setOrigin(0, 0.5);
    this.add.image(516, 30, 'diamond').setDepth(1001).setScale(0.9);
    this.diamondText = this.uiText(534, 30, '0', 26, '#9fe8ff').setOrigin(0, 0.5);
    this.muteBtn = this.uiText(688, 30, isMuted() ? '🔇' : '🔊', 28).setOrigin(0.5).setInteractive({ useHandCursor: true })
      .on('pointerdown', () => {
        setMuted(!isMuted());
        this.S.muted = isMuted(); writeSave(this.S);
        this.muteBtn.setText(isMuted() ? '🔇' : '🔊');
      });

    // Boss 血条
    this.bossBarBg = this.add.rectangle(W / 2, 74, 604, 14, 0x000000, 0.6).setDepth(1000).setVisible(false);
    this.bossBar = this.add.rectangle(W / 2 - 300, 74, 600, 10, 0xe84a5f).setOrigin(0, 0.5).setDepth(1001).setVisible(false);

    // 下一波预告
    this.previewText = this.uiText(W / 2, 110, '', 24, '#c9d2f0').setOrigin(0.5);

    // 底部面板（背景图模式半透明，露出城堡）
    this.add.rectangle(W / 2, 1130, W, 300, 0x161825, this.hasBg ? 0.82 : 0.95).setDepth(1000);

    // 提前召唤
    this.callBtn = makeButton(this, W / 2, 1012, 340, 58, '⚔ 提前召唤 +10%金币', {
      bg: 0x6b5a2e, stroke: 0xd8b74f, fontSize: 24,
      onClick: () => this.startWave(true),
    }).setDepth(1002).setVisible(false);

    // 买塔（核心按钮）
    this.buyBtn = makeButton(this, 360, 1155, 290, 130, '', {
      bg: 0x2e6b4f, stroke: 0x59c98f, fontSize: 30,
      onClick: () => this.buyTower(),
    }).setDepth(1002);

    // 回收区
    this.sellRect = new Phaser.Geom.Rectangle(30, 1090, 160, 130);
    this.sellZone = this.add.rectangle(110, 1155, 160, 130, 0x5a2e35, 1).setStrokeStyle(2, 0x9c4a58).setDepth(1001);
    this.sellText = this.uiText(110, 1155, '♻\n回收 50%', 22, '#ff9aa8').setOrigin(0.5).setDepth(1002);

    // 广告送塔
    this.giftBtn = makeButton(this, 610, 1105, 180, 70, '', {
      bg: 0x6b4a86, stroke: 0xb07fe0, fontSize: 20,
      onClick: () => this.adGiftTower(),
    }).setDepth(1002);

    // 2 倍速（局外解锁后显示）
    this.speedBtn = makeButton(this, 610, 1195, 180, 70, '▶ x1', {
      bg: 0x3b4568, fontSize: 24,
      onClick: () => this.toggleSpeed(),
    }).setDepth(1002).setVisible(tier(this.S, 'speed2x') > 0);

    this.updateUI();
  }

  uiText(x, y, str, size = 24, color = '#ffffff') {
    return this.add.text(x, y, str, {
      fontFamily: 'Arial, "Microsoft YaHei", sans-serif', fontSize: size + 'px',
      color, fontStyle: 'bold',
    }).setDepth(1001);
  }

  updateUI() {
    this.waveText.setText(`第 ${this.wave} 波`);
    this.heartText.setText(`❤ ${Math.max(0, this.baseHp)}`);
    this.goldText.setText(String(Math.floor(this.gold)));
    this.diamondText.setText(String(this.S.diamonds + this.diamondsRun));
    const cost = towerCost(this.bought);
    this.buyBtn.label.setText(`造 塔\n💰 ${cost}`);
    const afford = this.gold >= cost && this.slots.some(s => !s.tower);
    this.buyBtn.bg.setFillStyle(afford ? 0x2e6b4f : 0x33384a);
    const giftLeft = 2 - this.adGifts;
    this.giftBtn.label.setText(giftLeft > 0 ? `📺 送高级塔\n(剩${giftLeft}次)` : '📺 已用完');
    this.giftBtn.setEnabled(giftLeft > 0);
  }

  // ================= 开局预置 =================
  presetTowers() {
    const elems = unlockedElements(this.S);
    const elem = Phaser.Utils.Array.GetRandom(elems);
    const a = this.slots[6], b = this.slots[7]; // 中排相邻两格
    a.tower = new Tower(this, a, elem, 1);
    b.tower = new Tower(this, b, elem, 1);
    this.towers.push(a.tower, b.tower);
    if (this.S.runs === 0) {
      // 首局手势引导：拖到一起
      this.hint = this.uiText(W / 2, 545, '👆 拖动合成同色塔！', 30, '#ffe97a').setOrigin(0.5).setDepth(2000);
      this.hintHand = this.uiText(a.x, a.y - 30, '👆', 40).setOrigin(0.5).setDepth(2001);
      this.tweens.add({ targets: this.hintHand, x: b.x, y: b.y - 30, duration: 900, repeat: -1, hold: 300, repeatDelay: 300 });
    }
  }

  clearHint() {
    if (this.hint) { this.hint.destroy(); this.hintHand.destroy(); this.hint = null; }
  }

  // ================= 波次系统 =================
  composeWave(w) {
    const list = [];
    if (w % 5 === 0) {
      const bosses = w < 20 ? 1 : w < 30 ? 2 : 3 + Math.floor((w - 30) / 20);
      for (let i = 0; i < bosses; i++) list.push('boss');
      if (w >= 10) {
        const guards = Math.min(14, waveCount(w) - bosses);
        for (let i = 0; i < guards; i++) list.push(Math.random() < 0.7 ? 'slime' : 'runner');
      }
      return list;
    }
    const pool = [['slime', 40]];
    if (w >= ENEMY_TYPES.runner.from) pool.push(['runner', 25]);
    if (w >= ENEMY_TYPES.tank.from) pool.push(['tank', 18]);
    if (w >= ENEMY_TYPES.flyer.from) pool.push(['flyer', 15]);
    if (w >= ENEMY_TYPES.splitter.from) pool.push(['splitter', 14]);
    const total = pool.reduce((s, p) => s + p[1], 0);
    const n = waveCount(w);
    for (let i = 0; i < n; i++) {
      let r = Math.random() * total;
      for (const [k, wgt] of pool) { r -= wgt; if (r <= 0) { list.push(k); break; } }
      if (list.length <= i) list.push('slime');
    }
    this.markEliteWave(list, w);
    return list;
  }

  markEliteWave(list, w) {
    if (w < ELITE.fromWave || w % 5 === 0 || !list.length) return;
    const chance = w >= ELITE.lateWave ? ELITE.lateChance : ELITE.chance;
    if (Math.random() >= chance) return;

    const idx = Phaser.Math.Between(0, list.length - 1);
    const affixKeys = Object.keys(ELITE.affixes);
    list[idx] = {
      type: list[idx],
      eliteAffix: Phaser.Utils.Array.GetRandom(affixKeys),
    };
  }

  startPrep() {
    if (this.over || this.dying) return;
    this.waveState = 'prep';
    this.pending = this.composeWave(this.wave);
    // 预告图标（去重）
    const icons = this.previewIcons(this.pending);
    this.previewText.setText(`下一波 ▶ ${icons}`);
    this.callBtn.setVisible(true);
    this.prepTimer = this.time.delayedCall(4000, () => this.startWave(false));
    this.updateUI();
  }

  startWave(early) {
    if (this.evolutionChoiceOpen) {
      this.prepTimer = this.time.delayedCall(300, () => this.startWave(early));
      return;
    }
    if (this.waveState !== 'prep' || this.over || this.dying) return;
    if (this.prepTimer) this.prepTimer.remove();
    this.waveGoldMult = early ? 1.1 : 1.0;
    this.holyHealThisWave = 0;
    this.callBtn.setVisible(false);
    this.previewText.setText('');
    this.waveState = 'active';
    Sfx.wave();
    this.banner(`Wave ${this.wave}`);
    if (this.wave % 5 === 0) { Sfx.bossIn(); this.cameras.main.shake(350, 0.006); }

    const queue = this.pending.slice();
    this.spawnLeft = queue.length;
    const interval = Phaser.Math.Clamp(15 / queue.length, 0.35, 1.2) * 1000;
    let i = 0;
    this.spawnEvent = this.time.addEvent({
      delay: interval, repeat: queue.length - 1, startAt: interval - 200,
      callback: () => {
        if (this.over || this.dying) return;
        const item = queue[i++];
        if (typeof item === 'string') this.spawnEnemy(item);
        else this.spawnEnemy(item.type, { eliteAffix: item.eliteAffix, hpMult: ELITE.hpMult });
        this.spawnLeft--;
      },
    });
  }

  previewIcons(list) {
    const icons = [];
    const seen = new Set();
    for (const item of list) {
      const type = typeof item === 'string' ? item : item.type;
      const eliteAffix = typeof item === 'string' ? null : item.eliteAffix;
      const icon = eliteAffix ? `${TYPE_ICON[type]}${ELITE_ICON[eliteAffix]}` : TYPE_ICON[type];
      const key = eliteAffix ? `${type}_${eliteAffix}` : type;
      if (seen.has(key)) continue;
      seen.add(key);
      icons.push(icon);
    }
    return icons.join(' ');
  }

  spawnEnemy(typeKey, opts = {}) {
    const t = ENEMY_TYPES[typeKey];
    const path = t.flying ? this.flyPath : this.path;
    const e = new Enemy(this, typeKey, this.wave, path, opts);
    e.spawnWave = this.wave;
    this.enemies.push(e);
    return e;
  }

  banner(text) {
    const b = this.uiText(W / 2, 400, text, 56, '#ffffff').setOrigin(0.5).setDepth(2500).setScale(0);
    b.setStroke('#000000', 8);
    this.tweens.add({
      targets: b, scale: 1, duration: 260, ease: 'Back.Out',
      onComplete: () => this.tweens.add({ targets: b, alpha: 0, y: 360, delay: 650, duration: 350, onComplete: () => b.destroy() }),
    });
  }

  checkWaveClear() {
    if (this.waveState !== 'active' || this.over || this.dying) return;
    if (this.spawnLeft <= 0 && this.enemies.length === 0) {
      if (this.lastStandActive) {
        if (!this.lastStandLeaked) this.finishLastStand(true);
        return;
      }
      this.endWave();
    }
  }

  endWave() {
    this.waveState = 'idle';
    this.resonanceGoldMult = 1;
    this.holyHealThisWave = 0;
    // 利息（GDD §5.3：5%/档，单波上限 50×档）
    const it = tier(this.S, 'interest');
    if (it > 0) {
      const gain = Math.min(Math.floor(this.gold * 0.05 * it), 50 * it);
      if (gain > 0) { this.gold += gain; toast(this, 380, 200, `利息 +${gain}💰`, '#ffd34e', 24); }
    }
    const finished = this.wave;
    this.wave++;
    // 里程碑钻石
    if (finished % 10 === 0) {
      this.diamondsRun += DIAMOND.milestone;
      toast(this, W / 2, 300, `里程碑! +${DIAMOND.milestone}💎`, '#9fe8ff', 32);
      Sfx.diamond();
    }
    // 阶段色调切换（GDD §2）
    const oldPh = phaseFor(finished), newPh = phaseFor(this.wave);
    if (oldPh !== newPh) {
      this.banner(`${newPh.name}降临`);
      if (this.hasBg) {
        // 背景图模式：用叠色层做阶段氛围（白天透明，其余 0.22）
        this.phaseOverlay.setFillStyle(newPh.bg, this.phaseOverlay.fillAlpha);
        this.tweens.add({ targets: this.phaseOverlay, fillAlpha: newPh === PHASES[0] ? 0 : 0.22, duration: 1200 });
      } else {
        this.tintTo(this.bgAll, oldPh.bg, newPh.bg);
        this.tintTo(this.ground, oldPh.ground, newPh.ground);
      }
    }
    this.updateUI();
    this.startPrep();
  }

  tintTo(rect, from, to) {
    const a = Phaser.Display.Color.IntegerToColor(from), b = Phaser.Display.Color.IntegerToColor(to);
    this.tweens.addCounter({
      from: 0, to: 100, duration: 1200,
      onUpdate: tw => {
        const c = Phaser.Display.Color.Interpolate.ColorWithColor(a, b, 100, tw.getValue());
        rect.setFillStyle(Phaser.Display.Color.GetColor(c.r, c.g, c.b));
      },
    });
  }

  // ================= 敌人事件 =================
  onEnemyDead(e, cause) {
    this.enemies = this.enemies.filter(x => x !== e);
    if (this.over) { e.destroy(); return; }
    this.kills++;
    // 金币（GDD §4.3）
    const g = Math.max(1, Math.round(waveHp(e.spawnWave) * 0.1 * e.type.goldMult * e.rewardGoldMult * e.killGoldMult * this.waveGoldMult * this.resonanceGoldMult));
    this.gold += g;
    this.burst(e.x, e.y, e.type.color, e.boss ? 40 : 12, e.boss ? 1.6 : 1);
    this.coinFly(e.x, e.y);
    const now = this.time.now;
    if (now - this.lastKillSfx > 90) { Sfx.kill(); this.lastKillSfx = now; }

    if (e.boss) {
      this.diamondsRun += DIAMOND.boss;
      toast(this, e.x, e.y - 60, `+${DIAMOND.boss}💎`, '#9fe8ff', 34);
      Sfx.bossDie();
      this.cameras.main.shake(400, 0.012);
      this.slowmoT = 0.25;
    }
    if (e.elite) {
      this.diamondsRun += DIAMOND.elite;
      toast(this, e.x, e.y - 78, `精英 +${DIAMOND.elite}💎`, '#9fe8ff', 28);
      Sfx.diamond();
      this.burst(e.x, e.y, ELITE.affixes[e.eliteAffix].color, 24, 1.2);
    }
    // 分裂怪（GDD §4.2）
    if (e.type.splits && !this.dying) {
      this.spawnEnemy('mini', { progress: Math.max(0, e.progress - 18) });
      this.spawnEnemy('mini', { progress: e.progress + 18 });
      this.spawnLeft += 0; // 计数不变，enemies 数组已含
    }
    if (e.eliteAffix === 'split' && !this.dying) {
      for (let i = 0; i < 4; i++) {
        this.spawnEnemy('mini', { progress: e.progress + Phaser.Math.Between(-28, 28) });
      }
    }
    // 瘟疫分支尸爆传染（GDD §3.5）
    if (cause === 'poison' && e.poisons.some(p => p.plague)) {
      const src = e.poisons.find(p => p.plague);
      const radius = src.plagueRadius || 95;
      this.burst(e.x, e.y, 0x7ede55, 20, 1.3);
      for (const o of this.enemies) {
        if (Phaser.Math.Distance.Between(e.x, e.y, o.x, o.y) < radius) {
          o.applyPoison(src.dps, 2, false);
          o.killGoldMult = Math.max(o.killGoldMult || 1, src.goldMult || 1);
        }
      }
    }
    e.destroy();
    this.updateUI();
    this.checkWaveClear();
  }

  onEnemyLeak(e) {
    const leakedType = e.typeKey;
    e.dead = true;
    this.enemies = this.enemies.filter(x => x !== e);
    e.destroy();
    if (this.over || this.dying) return;
    this.leakStats[leakedType] = (this.leakStats[leakedType] || 0) + 1;
    if (this.lastStandActive) this.lastStandLeaked = true;
    this.baseHp -= e.boss ? LEAK_BOSS : LEAK_NORMAL;
    Sfx.leak();
    this.vignette.setAlpha(0.28);
    this.tweens.add({ targets: this.vignette, alpha: 0, duration: 400 });
    this.cameras.main.shake(150, 0.006);
    this.updateUI();
    if (this.baseHp <= 0) {
      if (!this.lastStandActive) this.baseDestroyed();
    }
    else this.checkWaveClear();
  }

  // ================= 买塔 / 合成 / 卖塔 =================
  smartRandomElem(spawnLv) {
    const unlocked = unlockedElements(this.S);
    // 智能随机（GDD §3.1）：60% 偏向可立即配对的颜色
    const pairable = [...new Set(this.towers.filter(t => t.lv === spawnLv).map(t => t.elem))]
      .filter(e => unlocked.includes(e));
    if (pairable.length && Math.random() < 0.6) return Phaser.Utils.Array.GetRandom(pairable);
    return Phaser.Utils.Array.GetRandom(unlocked);
  }

  randomBranch(elem) {
    const keys = Object.keys(TOWER_BRANCHES[elem] || {});
    return Phaser.Utils.Array.GetRandom(keys);
  }

  buyTower(silent) {
    if (this.evolutionChoiceOpen) return false;
    const cost = towerCost(this.bought);
    if (this.gold < cost) { if (!silent) toast(this, 360, 1020, '金币不足', '#ff8888', 24); return false; }
    const free = this.slots.filter(s => !s.tower);
    if (!free.length) { if (!silent) toast(this, 360, 1020, '塔位已满，先合成!', '#ff8888', 24); return false; }
    this.gold -= cost;
    this.bought++;
    let lv = spawnFloor(this.wave);
    if (Math.random() < 0.05 * tier(this.S, 'startLv')) lv = Math.min(MAX_LV, lv + 1);
    const elem = this.smartRandomElem(lv);
    const branch = lv >= 4 ? this.randomBranch(elem) : null;
    const slot = Phaser.Utils.Array.GetRandom(free);
    this.placeTower(slot, elem, lv, branch);
    Sfx.buy();
    this.updateUI();
    return true;
  }

  placeTower(slot, elem, lv, branch = null) {
    const t = new Tower(this, slot, elem, lv, branch);
    slot.tower = t;
    this.towers.push(t);
    t.c.setScale(0);
    this.tweens.add({ targets: t.c, scale: 1, duration: 240, ease: 'Back.Out' });
    this.burst(slot.x, slot.y - 20, ELEMENTS[elem].color, 8, 0.7);
    if (lv > this.highestLv) this.highestLv = lv;
    return t;
  }

  doMerge(a, b, opts = {}) {
    // b 的位置保留，产出 lv+1
    const slot = b.slot, elem = a.elem, lv = a.lv + 1;
    const branch = this.mergeBranchFor(a, b, lv, opts);
    a.slot.tower = null; slot.tower = null;
    this.towers = this.towers.filter(t => t !== a && t !== b);
    a.destroy(); b.destroy();
    const t = this.placeTower(slot, elem, lv, branch);
    const resonance = this.registerMergeResonance(t, !!opts.auto);
    // —— 合成爆点（GDD §6.1）——
    t.c.setScale(1.45);
    this.tweens.add({ targets: t.c, scale: 1, duration: 300, ease: 'Bounce.Out' });
    this.burst(slot.x, slot.y - 24, ELEMENTS[elem].color, 18, 1.1);
    Sfx.merge(lv, resonance.chain);
    this.triggerMergeSurge(t, resonance.multiplier, resonance.chain, !!opts.auto);
    this.clearHint();
    // 里程碑质变提示（GDD §3.3）
    if (lv === 4 || lv === 7) toast(this, slot.x, slot.y - 90, '⭐ 里程碑质变!', '#ffe97a', 26);
    if (lv === 4 && !opts.auto) this.showEvolutionChoice(t);
    // 本局最高级：慢镜 + 白闪（GDD §6.2）
    if (lv > this.highestLv || lv === this.highestLv) {
      if (lv >= this.highestLv && lv > 2) {
        this.highestLv = lv;
        this.slowmoT = 0.3;
        this.flash.setAlpha(0.55);
        this.tweens.add({ targets: this.flash, alpha: 0, duration: 450 });
        Sfx.mergeTop();
      }
      this.highestLv = Math.max(this.highestLv, lv);
    }
    this.updateUI();
  }

  mergeBranchFor(a, b, lv, opts = {}) {
    if (lv < 4) return null;
    if (lv === 4) return opts.auto ? 'a' : null;
    return b.branch || a.branch || 'a';
  }

  showEvolutionChoice(t) {
    if (this.evolutionLayer) this.evolutionLayer.destroy();
    this.evolutionChoiceOpen = true;
    this.slowmoT = Math.max(this.slowmoT, 0.5);
    this.evolutionPrevTimeScale = this.time.timeScale;
    this.evolutionPrevTweenScale = this.tweens.timeScale;
    this.time.timeScale = 0;
    this.tweens.timeScale = 0;

    const defs = TOWER_BRANCHES[t.elem];
    const layer = this.add.container(0, 0).setDepth(4100);
    this.evolutionLayer = layer;
    layer.add(this.add.rectangle(W / 2, H / 2, W, H, 0x000000, 0.68).setInteractive());

    const title = this.uiText(W / 2, 420, `${ELEMENTS[t.elem].cn} Lv4 进化`, 42, '#ffffff').setOrigin(0.5);
    title.setStroke('#000000', 8);
    layer.add(title);

    const choose = branch => {
      if (!this.evolutionChoiceOpen) return;
      t.setBranch(branch);
      this.resumeEvolutionChoice();
      this.evolutionChoiceOpen = false;
      this.evolutionLayer = null;
      layer.destroy();
      const def = defs[branch];
      toast(this, t.slot.x, t.slot.y - 110, `${def.cn} 分支`, this.hexColor(t.color), 28);
      this.burst(t.slot.x, t.slot.y - 26, t.color, 18, 1.1);
    };

    const addCard = (x, branch) => {
      const def = defs[branch];
      const card = this.add.rectangle(x, 615, 270, 270, 0x1e2233, 0.96)
        .setStrokeStyle(3, t.color, 0.92)
        .setInteractive({ useHandCursor: true });
      const badge = this.add.circle(x, 520, 30, t.color, 0.28).setStrokeStyle(3, t.color, 0.9);
      const short = this.uiText(x, 520, def.short, 30, '#ffffff').setOrigin(0.5);
      const name = this.uiText(x, 575, def.cn, 30, '#ffe97a').setOrigin(0.5);
      const desc = this.add.text(x, 645, def.desc, {
        fontFamily: 'Arial, "Microsoft YaHei", sans-serif',
        fontSize: '22px',
        color: '#dce5ff',
        fontStyle: 'bold',
        align: 'center',
        wordWrap: { width: 220 },
      }).setOrigin(0.5).setDepth(4101);
      const pick = this.uiText(x, 725, '选择', 24, '#ffffff').setOrigin(0.5);
      pick.setStroke('#000000', 5);

      card.on('pointerdown', () => choose(branch));
      card.on('pointerover', () => card.setFillStyle(0x2b3150, 1));
      card.on('pointerout', () => card.setFillStyle(0x1e2233, 0.96));
      for (const obj of [card, badge, short, name, desc, pick]) layer.add(obj);
    };

    addCard(215, 'a');
    addCard(505, 'b');
  }

  resumeEvolutionChoice() {
    this.time.timeScale = this.evolutionPrevTimeScale ?? this.speedMult;
    this.tweens.timeScale = this.evolutionPrevTweenScale ?? this.speedMult;
    this.evolutionPrevTimeScale = null;
    this.evolutionPrevTweenScale = null;
  }

  registerMergeResonance(t, auto) {
    if (auto) {
      return { chain: 1, multiplier: MERGE_SURGE.autoMultiplier };
    }

    const now = this.time.now;
    this.resonanceStacks = now <= this.resonanceDeadline ? this.resonanceStacks + 1 : 1;
    this.resonanceDeadline = now + MERGE_SURGE.resonanceWindow * 1000;

    const chain = this.resonanceStacks;
    const multiplier = Math.min(
      MERGE_SURGE.resonanceCap,
      1 + MERGE_SURGE.resonanceStep * (chain - 1),
    );

    this.showResonanceWindow(t);
    if (chain > 1) this.comboPop(t, chain);
    this.applyResonanceMilestone(t, chain);
    return { chain, multiplier };
  }

  showResonanceWindow(t) {
    if (this.resonanceRing) this.resonanceRing.destroy();
    const ring = this.add.circle(t.slot.x, t.slot.y - 8, 58, t.color, 0.04)
      .setStrokeStyle(4, t.color, 0.9)
      .setDepth(2240);
    this.resonanceRing = ring;
    this.tweens.add({
      targets: ring,
      scale: 0.66,
      alpha: 0,
      duration: MERGE_SURGE.resonanceWindow * 1000,
      ease: 'Linear',
      onComplete: () => {
        if (this.resonanceRing === ring) this.resonanceRing = null;
        ring.destroy();
      },
    });
  }

  comboPop(t, chain) {
    const txt = this.uiText(t.slot.x + 38, t.slot.y - 94, `×${chain}`, 34, this.hexColor(t.color))
      .setOrigin(0.5)
      .setDepth(2600)
      .setScale(0.55);
    txt.setStroke('#000000', 7);
    this.tweens.add({
      targets: txt,
      y: txt.y - 42,
      scale: 1 + Math.min(chain, 7) * 0.06,
      alpha: 0,
      duration: 760,
      ease: 'Back.Out',
      onComplete: () => txt.destroy(),
    });
  }

  applyResonanceMilestone(t, chain) {
    if (chain >= 3) this.screenGlow(t.color, chain >= 5 ? 0.18 : 0.12);
    if (chain === 3) {
      this.banner('连锁共鸣!');
      this.applyGlobalResonanceSlow(t.color);
      Sfx.resonance(chain);
    } else if (chain === 5) {
      this.banner('共鸣馈赠!');
      this.grantResonanceTower(t);
      this.cameras.main.shake(180, 0.004);
      Sfx.resonance(chain);
    } else if (chain === 7) {
      this.resonanceGoldMult = Math.max(this.resonanceGoldMult, 2);
      this.banner('金币共鸣 ×2');
      toast(this, t.slot.x, t.slot.y - 120, '本波金币 ×2', '#ffd34e', 28);
      Sfx.resonance(chain);
    }
  }

  applyGlobalResonanceSlow(color) {
    for (const e of this.enemies) {
      if (e.dead) continue;
      e.applySlow(MERGE_SURGE.resonanceSlowPct, MERGE_SURGE.resonanceSlowDuration, MERGE_SURGE.resonanceSlowPct);
      this.burst(e.x, e.y, color, 4, 0.35);
    }
  }

  grantResonanceTower(src) {
    const free = this.slots.filter(s => !s.tower);
    if (!free.length) {
      toast(this, src.slot.x, src.slot.y - 120, '塔位已满', '#ff8888', 24);
      return;
    }

    const lv = spawnFloor(this.wave);
    const slot = Phaser.Utils.Array.GetRandom(free);
    const elem = this.smartRandomElem(lv);
    const branch = lv >= 4 ? this.randomBranch(elem) : null;
    const t = this.placeTower(slot, elem, lv, branch);
    t.c.setPosition(src.slot.x, src.slot.y - 88);
    t.c.setDepth(2650);
    this.tweens.add({
      targets: t.c,
      x: slot.x,
      y: slot.y - 8,
      duration: 520,
      ease: 'Cubic.Out',
      onComplete: () => t.moveTo(slot),
    });
    Sfx.buy();
  }

  triggerMergeSurge(t, multiplier, chain, auto) {
    const x = t.slot.x, y = t.slot.y - 8;
    const ring = this.add.circle(x, y, 74, t.color, auto ? 0.04 : 0.08)
      .setStrokeStyle(auto ? 3 : 5, t.color, auto ? 0.38 : 0.72)
      .setScale(0.18)
      .setDepth(2140);
    this.tweens.add({
      targets: ring,
      scale: Math.max(1.4, t.range / 74),
      alpha: 0,
      duration: 480,
      ease: 'Cubic.Out',
      onComplete: () => ring.destroy(),
    });
    this.burst(x, y - 18, t.color, auto ? 10 : 24, auto ? 0.8 : 1.2);
    Sfx.surge();

    if (t.elem === 'fire') this.surgeFire(t, multiplier);
    else if (t.elem === 'ice') this.surgeIce(t, multiplier);
    else if (t.elem === 'lightning') this.surgeLightning(t, multiplier);
    else if (t.elem === 'poison') this.surgePoison(t, multiplier);
    else if (t.elem === 'light') this.surgeLight(t, multiplier);
  }

  surgeFire(t, multiplier) {
    const pts = this.pathSamplesNear(this.path, t.slot.x, t.slot.y, t.range, 46)
      .sort((a, b) => a.progress - b.progress);
    const dps = t.dmg * 0.5 * multiplier;
    const targets = pts.length ? pts : [{ x: t.slot.x, y: t.slot.y, progress: 0 }];
    targets.forEach((p, i) => {
      this.time.delayedCall(i * 28, () => {
        if (this.over) return;
        this.addBurnZone(p.x, p.y, dps, {
          duration: MERGE_SURGE.fireDuration,
          radius: MERGE_SURGE.fireRadius,
          color: t.color,
          scale: 2.15,
          goldMult: t.goldMult,
        });
        if (i % 2 === 0) this.burst(p.x, p.y, t.color, 5, 0.45);
      });
    });
  }

  surgeIce(t, multiplier) {
    const ground = this.enemies.filter(e => !e.dead && !e.flying);
    const center = ground.length ? Math.max(...ground.map(e => e.progress)) : this.path.total * 0.65;
    const span = 180 + t.lv * 18;
    const duration = (1 + 0.2 * t.lv) * multiplier;
    const pts = [];

    for (let d = Math.max(0, center - span); d <= Math.min(this.path.total, center + span); d += 42) {
      pts.push(this.path.pointAt(d));
    }

    if (pts.length > 1) {
      const g = this.add.graphics().setDepth(2130);
      g.lineStyle(14, t.color, 0.28);
      g.strokePoints(pts.map(p => new Phaser.Math.Vector2(p.x, p.y)), false);
      g.lineStyle(4, 0xffffff, 0.52);
      g.strokePoints(pts.map(p => new Phaser.Math.Vector2(p.x, p.y)), false);
      this.tweens.add({ targets: g, alpha: 0, duration: 560, onComplete: () => g.destroy() });
    }

    for (const e of ground) {
      if (Math.abs(e.progress - center) > span) continue;
      if (e.applyFreeze(duration)) this.showDmg(e.x, e.y - 42, '冻结', '#bfe8ff');
    }
    Sfx.freeze();
  }

  surgeLightning(t, multiplier) {
    const targets = this.enemies
      .filter(e => !e.dead)
      .sort((a, b) => b.progress - a.progress)
      .slice(0, 3 + t.lv);
    if (!targets.length) return;

    const g = this.add.graphics().setDepth(2140);
    g.lineStyle(4, 0xfff2a8, 0.96);
    let px = t.slot.x, py = t.slot.y - 58;
    for (const e of targets) {
      this.zigzag(g, px, py, e.x, e.y - 10);
      px = e.x; py = e.y - 10;
    }
    this.tweens.add({ targets: g, alpha: 0, duration: 220, onComplete: () => g.destroy() });

    for (const e of targets) {
      if (e.dead) continue;
      const real = e.takeDamage(t.dmg * 1.5 * multiplier, { cause: 'surge', sourceTower: t });
      this.showDmg(e.x, e.y - 44, real, '#fff2a8');
      this.burst(e.x, e.y, t.color, 7, 0.6);
    }
    Sfx.hit();
  }

  surgePoison(t, multiplier) {
    const x = t.slot.x, y = t.slot.y;
    const cloud = this.add.image(x, y, 'glow')
      .setTint(t.color)
      .setAlpha(0.5)
      .setScale(MERGE_SURGE.poisonRadius / 30)
      .setDepth(2120);
    this.tweens.add({
      targets: cloud,
      scale: MERGE_SURGE.poisonRadius / 24,
      alpha: 0,
      duration: 850,
      ease: 'Cubic.Out',
      onComplete: () => cloud.destroy(),
    });

    for (const e of this.enemies) {
      if (e.dead) continue;
      const d = Phaser.Math.Distance.Between(x, y, e.x, e.y);
      if (d > MERGE_SURGE.poisonRadius + this.enemySize(e) * 0.5) continue;
      const aliveStacks = e.poisons.filter(p => p.t > 0).length;
      e.applyPoison(t.dmg * multiplier, aliveStacks + 1, false, t, { branchEffects: false });
      this.showDmg(e.x, e.y - 42, '☠', '#9ef07a');
    }
  }

  surgeLight(t, multiplier) {
    const count = Phaser.Math.Clamp(Math.floor(multiplier), 1, 3);
    const targets = this.enemies
      .filter(e => !e.dead && !e.boss)
      .sort((a, b) => (a.hp / a.maxHp) - (b.hp / b.maxHp))
      .slice(0, count);

    if (targets.length) {
      targets.forEach((e, i) => {
        this.time.delayedCall(i * 70, () => {
          if (e.dead) return;
          this.lightBeam(t.slot.x, t.slot.y - 70, e.x, e.y - 10);
          this.showDmg(e.x, e.y - 54, '处决!', '#fff8dc');
          this.burst(e.x, e.y, t.color, 18, 1);
          e.takeDamage(e.hp + 1, { trueDmg: true, cause: 'execute', sourceTower: t });
        });
      });
      Sfx.execute();
      return;
    }

    const heal = Math.min(this.maxBase - this.baseHp, count);
    if (heal > 0) {
      this.baseHp += heal;
      toast(this, 560, 940, `+${heal}❤`, '#fff8dc', 30);
      this.updateUI();
    } else {
      toast(this, t.slot.x, t.slot.y - 110, '圣光守护', '#fff8dc', 24);
    }
    this.screenGlow(t.color, 0.12);
  }

  lightBeam(x1, y1, x2, y2) {
    const g = this.add.graphics().setDepth(2140);
    g.lineStyle(8, 0xfff8dc, 0.85);
    g.lineBetween(x1, y1, x2, y2);
    g.lineStyle(18, 0xfff8dc, 0.22);
    g.lineBetween(x1, y1, x2, y2);
    this.tweens.add({ targets: g, alpha: 0, duration: 240, onComplete: () => g.destroy() });
  }

  pathSamplesNear(path, x, y, radius, step) {
    const pts = [];
    for (let d = 0; d <= path.total; d += step) {
      const p = path.pointAt(d);
      if (Phaser.Math.Distance.Between(x, y, p.x, p.y) <= radius) pts.push({ ...p, progress: d });
    }
    return pts;
  }

  screenGlow(color, alpha) {
    const glow = this.add.rectangle(W / 2, H / 2, W, H, color, alpha).setDepth(2940);
    this.tweens.add({ targets: glow, alpha: 0, duration: 520, onComplete: () => glow.destroy() });
  }

  hexColor(color) {
    return '#' + color.toString(16).padStart(6, '0');
  }

  sellTower(t) {
    const refund = Math.round(towerCost(this.bought) * 0.5);
    this.gold += refund;
    t.slot.tower = null;
    this.towers = this.towers.filter(x => x !== t);
    this.burst(t.slot.x, t.slot.y - 20, 0xff9aa8, 10, 0.8);
    t.destroy();
    Sfx.sell();
    toast(this, 110, 1000, `+${refund}💰`, '#ffd34e', 26);
    this.updateUI();
  }

  async adGiftTower() {
    if (this.adGifts >= 2) return;
    const free = this.slots.filter(s => !s.tower);
    if (!free.length) { toast(this, 610, 980, '塔位已满', '#ff8888', 22); return; }
    const ok = await Poki.rewardedBreak();
    if (!ok) return;
    this.adGifts++;
    const lv = Math.min(MAX_LV, Math.max(3, spawnFloor(this.wave)));
    const elem = this.smartRandomElem(lv);
    const branch = lv >= 4 ? this.randomBranch(elem) : null;
    this.placeTower(Phaser.Utils.Array.GetRandom(free), elem, lv, branch);
    Sfx.merge(lv);
    this.updateUI();
  }

  autoBuyTick() {
    if (!tier(this.S, 'autoBuy') || this.over || this.dying || this.evolutionChoiceOpen) return;
    this.buyTower(true);
  }

  autoMergeTick() {
    if (!tier(this.S, 'autoMerge') || this.over || this.dying || this.evolutionChoiceOpen) return;
    // 找最高等级的可合成对
    const groups = {};
    for (const t of this.towers) {
      if (t.lv >= MAX_LV || t.dragging) continue;
      const k = t.elem + '_' + t.lv;
      (groups[k] = groups[k] || []).push(t);
    }
    let best = null;
    for (const k in groups) {
      if (groups[k].length >= 2 && (!best || groups[k][0].lv > best[0].lv)) best = groups[k];
    }
    if (best) this.doMerge(best[0], best[1], { auto: true });
  }

  toggleSpeed() {
    this.speedMult = this.speedMult === 1 ? 2 : 1;
    this.time.timeScale = this.speedMult;
    this.tweens.timeScale = this.speedMult;
    this.speedBtn.label.setText(`▶ x${this.speedMult}`);
  }

  // ================= 拖拽 =================
  setupDrag() {
    this.rangeCircle = this.add.circle(0, 0, 100, 0xffffff, 0.06).setStrokeStyle(2, 0xffffff, 0.35).setVisible(false).setDepth(900);

    this.input.on('dragstart', (pointer, obj) => {
      const t = obj.towerRef;
      if (!t || this.over || this.evolutionChoiceOpen) return;
      t.dragging = true;
      obj.setDepth(2600);
      this.rangeCircle.setPosition(t.slot.x, t.slot.y).setRadius(t.range).setVisible(true);
      this.sellZone.setStrokeStyle(3, 0xff6b7d).setScale(1.06);
      this.showFreeSlots(true);
      // 高亮可合成目标
      for (const o of this.towers) {
        if (o !== t && o.elem === t.elem && o.lv === t.lv && t.lv < MAX_LV) o.setHighlight(true);
      }
    });

    this.input.on('drag', (pointer, obj, dragX, dragY) => {
      if (!obj.towerRef) return;
      obj.setPosition(dragX, dragY);
    });

    this.input.on('dragend', (pointer, obj) => {
      const t = obj.towerRef;
      if (!t) return;
      t.dragging = false;
      this.rangeCircle.setVisible(false);
      this.sellZone.setStrokeStyle(2, 0x9c4a58).setScale(1);
      this.showFreeSlots(false);
      for (const o of this.towers) o.setHighlight(false);

      // 回收区
      if (this.sellRect.contains(obj.x, obj.y)) { this.sellTower(t); return; }
      // 找最近塔位
      let nearest = null, nd = 80;
      for (const s of this.slots) {
        const d = Phaser.Math.Distance.Between(obj.x, obj.y + 8, s.x, s.y);
        if (d < nd) { nd = d; nearest = s; }
      }
      if (!nearest || nearest === t.slot) { t.moveTo(t.slot); return; }
      if (!nearest.tower) {
        t.slot.tower = null;
        nearest.tower = t;
        t.moveTo(nearest);
      } else if (nearest.tower.elem === t.elem && nearest.tower.lv === t.lv && t.lv < MAX_LV) {
        this.doMerge(t, nearest.tower);
      } else {
        t.moveTo(t.slot);
      }
    });
  }

  // ================= 战斗 =================
  targetFor(tower) {
    let best = null, bestRemain = Infinity;
    for (const e of this.enemies) {
      if (e.dead) continue;
      const d = Phaser.Math.Distance.Between(tower.slot.x, tower.slot.y, e.x, e.y);
      if (d > tower.range + this.enemySize(e) * 0.5) continue;
      const remain = e.path.total - e.progress;
      if (remain < bestRemain) { bestRemain = remain; best = e; }
    }
    return best;
  }

  enemySize(e) {
    return e.type.size * (e.elite ? ELITE.sizeMult : 1);
  }

  eliteSpeedFactorFor(enemy) {
    if (enemy.dead) return 1;
    for (const e of this.enemies) {
      if (e === enemy || e.dead || e.eliteAffix !== 'haste') continue;
      if (Phaser.Math.Distance.Between(e.x, e.y, enemy.x, enemy.y) <= ELITE.auraRadius) return ELITE.auraSpeedMult;
    }
    return 1;
  }

  sourceBonusFor(t, target, opts = {}) {
    let bonus = this.holyAuraBonus(t);
    if (opts.shatter) bonus += t.lv >= 7 ? 2.5 : 1.5;
    return Math.min(1, bonus);
  }

  holyAuraBonus(t) {
    let bonus = 0;
    for (const aura of this.towers) {
      if (aura === t || aura.elem !== 'light' || aura.branch !== 'b' || aura.lv < 4) continue;
      const d = Phaser.Math.Distance.Between(aura.slot.x, aura.slot.y, t.slot.x, t.slot.y);
      if (d <= 230) bonus += aura.lv >= 7 ? 0.4 : 0.2;
    }
    return Math.min(1, bonus);
  }

  applyJudgementBuff(t) {
    if (t.elem !== 'light' || t.branch !== 'a' || t.lv < 4) return;
    if (t.lv >= 7) {
      this.atkBuffT = 3;
      this.atkBuffMult = Math.max(this.atkBuffMult || 1.3, 1.5);
      toast(this, t.slot.x, t.slot.y - 110, '审判：全场攻速+50%', '#fff8dc', 22);
    } else {
      t.selfBuffT = 3;
      toast(this, t.slot.x, t.slot.y - 110, '审判：攻速+50%', '#fff8dc', 22);
    }
  }

  tryHolyHeal(t) {
    if (t.elem !== 'light' || t.branch !== 'b' || t.lv < 4) return;
    const amount = t.lv >= 7 ? 2 : 1;
    const heal = Math.min(amount, this.maxBase - this.baseHp, 3 - this.holyHealThisWave);
    if (heal <= 0) return;
    this.baseHp += heal;
    this.holyHealThisWave += heal;
    toast(this, 560, 940, `圣辉 +${heal}❤`, '#fff8dc', 26);
    this.updateUI();
  }

  fireTower(t, target) {
    t.resetCooldown();
    t.recoil();
    const dmg = t.dmg;
    const lv = t.lv, elem = t.elem, color = t.color;
    const branch = lv >= 4 ? t.branch : null;
    const sx = t.slot.x, sy = t.slot.y - 50;

    if (elem === 'lightning') {
      // 连锁闪电：瞬发
      const chainN = 3 + (branch === 'a' ? 2 + (lv >= 7 ? 2 : 0) : 0);
      const chain = [target];
      while (chain.length < chainN) {
        const last = chain[chain.length - 1];
        let next = null, nd = 150;
        for (const e of this.enemies) {
          if (e.dead || chain.includes(e)) continue;
          const d = Phaser.Math.Distance.Between(last.x, last.y, e.x, e.y);
          if (d < nd) { nd = d; next = e; }
        }
        if (!next) break;
        chain.push(next);
      }
      const g = this.add.graphics().setDepth(2100);
      g.lineStyle(3, 0xfff2a8, 0.95);
      let px = sx, py = sy;
      for (const e of chain) { this.zigzag(g, px, py, e.x, e.y - 10); px = e.x; py = e.y - 10; }
      this.tweens.add({ targets: g, alpha: 0, duration: 180, onComplete: () => g.destroy() });
      chain.forEach((e, i) => {
        const mult = (branch === 'a' && i === chain.length - 1) ? 2 : 1;
        const real = e.takeDamage(dmg * mult, { sourceTower: t, sourceBonus: this.sourceBonusFor(t, e) });
        this.showDmg(e.x, e.y - 40, real, '#fff2a8');
        if (branch === 'b' && !e.dead) {
          const chance = lv >= 7 ? 0.25 : 0.15;
          if (Math.random() < chance && e.applyStun(e.boss ? 0.25 : 0.5)) {
            this.showDmg(e.x, e.y - 58, '眩晕', '#fff2a8');
            this.burst(e.x, e.y, 0xfff2a8, 8, 0.7);
          }
        }
      });
      Sfx.hit();
      return;
    }

    if (elem === 'light') {
      // 光束：瞬发 + 斩杀
      const g = this.add.graphics().setDepth(2100);
      g.lineStyle(5, 0xfff8dc, 0.9);
      g.lineBetween(sx, sy, target.x, target.y - 10);
      g.lineStyle(10, 0xfff8dc, 0.25);
      g.lineBetween(sx, sy, target.x, target.y - 10);
      this.tweens.add({ targets: g, alpha: 0, duration: 200, onComplete: () => g.destroy() });
      const threshold = branch === 'a' ? 0.25 : 0.15;
      if (target.hp / target.maxHp <= threshold) {
        this.showDmg(target.x, target.y - 50, '处决!', '#fff8dc');
        this.burst(target.x, target.y, 0xfff8dc, 16, 1.1);
        Sfx.execute();
        this.applyJudgementBuff(t);
        this.tryHolyHeal(t);
        target.takeDamage(target.hp + 1, { trueDmg: true, cause: 'execute', sourceTower: t, sourceBonus: this.sourceBonusFor(t, target) });
      } else {
        const mult = target.flying ? 1.5 : 1;
        const real = target.takeDamage(dmg * mult, { sourceTower: t, sourceBonus: this.sourceBonusFor(t, target) });
        this.showDmg(target.x, target.y - 40, real, '#fff8dc');
      }
      return;
    }

    // 弹道类：火 / 冰 / 毒
    const b = this.add.image(sx, sy, 'bullet').setTint(color).setDepth(2050).setScale(0.9);
    const dur = Phaser.Math.Distance.Between(sx, sy, target.x, target.y) / 1.4;
    this.tweens.add({
      targets: b, x: target.x, y: target.y - 10, duration: dur,
      onComplete: () => {
        const ix = b.x, iy = b.y;
        b.destroy();
        if (this.over) return;
        Sfx.hit();
        if (elem === 'fire') {
          if (branch === 'b') {
            if (target.dead) return;
            const crit = Math.random() < (lv >= 7 ? 0.5 : 0.3);
            const hit = dmg * 2.2 * (crit ? 3 : 1);
            const real = target.takeDamage(hit, { sourceTower: t, sourceBonus: this.sourceBonusFor(t, target) });
            this.showDmg(target.x, target.y - 44, crit ? `暴击 ${Math.round(real)}` : real, crit ? '#ffe97a' : '#ffb199');
            this.burst(target.x, target.y, crit ? 0xffe97a : color, crit ? 18 : 12, crit ? 1.2 : 0.85);
            return;
          }
          const radius = (62 + lv * 2) * (branch === 'a' ? 1.6 : 1);
          this.burst(ix, iy, color, 14, 1);
          for (const e of [...this.enemies]) {
            if (e.dead) continue;
            if (Phaser.Math.Distance.Between(ix, iy, e.x, e.y) <= radius + this.enemySize(e) * 0.5) {
              const real = e.takeDamage(dmg, { sourceTower: t, sourceBonus: this.sourceBonusFor(t, e) });
              this.showDmg(e.x, e.y - 40, real, '#ffb199');
            }
          }
          if (branch === 'a') this.addBurnZone(ix, iy, dmg * 0.5, { duration: lv >= 7 ? 4 : 2, goldMult: t.goldMult });
        } else if (elem === 'ice') {
          if (!target.dead) {
            const shatter = branch === 'b' && (target.slowT > 0 || target.frozenT > 0);
            const real = target.takeDamage(dmg, { sourceTower: t, sourceBonus: this.sourceBonusFor(t, target, { shatter }) });
            this.showDmg(target.x, target.y - 40, real, '#bfe8ff');
            target.applySlow(branch === 'a' ? 70 : 60);
            const freezeChance = branch === 'a' ? (lv >= 7 ? 0.2 : 0.1) : 0;
            if (freezeChance > 0 && Math.random() < freezeChance && !target.dead && target.applyFreeze(1)) {
              Sfx.freeze();
              this.burst(target.x, target.y, 0xbfe8ff, 10, 0.8);
            }
          }
        } else if (elem === 'poison') {
          if (!target.dead) {
            target.applyPoison(dmg, lv >= 4 ? 2 : 1, false, t);
            this.showDmg(target.x, target.y - 40, '☠', '#9ef07a');
          }
        }
      },
    });
  }

  zigzag(g, x1, y1, x2, y2) {
    const segs = 4;
    let px = x1, py = y1;
    for (let i = 1; i <= segs; i++) {
      const t = i / segs;
      const nx = x1 + (x2 - x1) * t + (i < segs ? Phaser.Math.Between(-12, 12) : 0);
      const ny = y1 + (y2 - y1) * t + (i < segs ? Phaser.Math.Between(-12, 12) : 0);
      g.lineBetween(px, py, nx, ny);
      px = nx; py = ny;
    }
  }

  addBurnZone(x, y, dps, opts = {}) {
    const duration = opts.duration ?? 2;
    const radius = opts.radius ?? 58;
    const color = opts.color ?? 0xff7733;
    const scale = opts.scale ?? 1.8;
    const img = this.add.image(x, y, 'glow').setTint(color).setAlpha(0.55).setScale(scale).setDepth(100);
    this.burnZones.push({ x, y, dps, t: duration, img, tick: 0, radius, goldMult: opts.goldMult || 1 });
  }

  // ================= 特效工具 =================
  burst(x, y, color, n = 12, scale = 1) {
    const p = this.add.particles(x, y, 'spark', {
      speed: { min: 60, max: 260 }, scale: { start: 0.85 * scale, end: 0 },
      lifespan: 420, tint: color, emitting: false,
    }).setDepth(2200);
    p.explode(n);
    this.time.delayedCall(700, () => p.destroy());
  }

  showDmg(x, y, val, color) {
    if (this.dmgCount > 34) return;
    this.dmgCount++;
    const str = typeof val === 'number' ? String(Math.max(0, Math.round(val))) : val;
    const t = this.add.text(x + Phaser.Math.Between(-14, 14), y, str, {
      fontFamily: 'Arial Black, sans-serif', fontSize: '22px', color, stroke: '#000000', strokeThickness: 4,
    }).setOrigin(0.5).setDepth(2300);
    this.tweens.add({
      targets: t, y: y - 48, alpha: 0, duration: 600, ease: 'Cubic.Out',
      onComplete: () => { t.destroy(); this.dmgCount--; },
    });
  }

  coinFly(x, y) {
    if (this.coinCount > 7) return;
    this.coinCount++;
    const c = this.add.image(x, y, 'coin').setDepth(2400);
    this.tweens.add({
      targets: c, x: 340, y: 30, scale: 0.7, duration: 480, ease: 'Cubic.In',
      onComplete: () => { c.destroy(); this.coinCount--; Sfx.coin(); },
    });
  }

  // ================= 死亡 / 复活 / 结算 =================
  baseDestroyed() {
    if (this.dying || this.over || this.lastStandActive) return;
    this.deathWave = this.wave;
    if (!this.lastStandUsed) {
      this.startLastStand();
      return;
    }
    this.showDefeatChoices();
  }

  startLastStand() {
    this.lastStandUsed = true;
    this.lastStandActive = true;
    this.lastStandT = 5;
    this.lastStandLeaked = false;
    this.baseHp = 0;
    this.updateUI();
    this.cameras.main.shake(500, 0.015);
    this.banner('最后一战!');
    Sfx.lastStand();

    this.lastStandOverlay = this.add.rectangle(W / 2, H / 2, W, H, 0x9b1022, 0)
      .setDepth(2250);
    this.tweens.add({ targets: this.lastStandOverlay, alpha: 0.28, duration: 220 });
    this.lastStandText = this.uiText(W / 2, 160, '最后一战 5.0', 34, '#ffccd2')
      .setOrigin(0.5)
      .setDepth(3000);
    this.lastStandText.setStroke('#390611', 7);
  }

  updateLastStand(realDt) {
    if (!this.lastStandActive) return;
    this.lastStandT -= realDt;
    if (this.lastStandText) this.lastStandText.setText(`最后一战 ${Math.max(0, this.lastStandT).toFixed(1)}`);
    if (!this.lastStandLeaked && this.spawnLeft <= 0 && this.enemies.length === 0) {
      this.finishLastStand(true);
    } else if (this.lastStandT <= 0) {
      this.finishLastStand(false);
    }
  }

  finishLastStand(success) {
    if (!this.lastStandActive) return;
    this.lastStandActive = false;
    this.clearLastStandFx();

    if (success) {
      this.baseHp = 1;
      this.updateUI();
      this.banner('绝地翻盘!');
      Sfx.clutch();
      this.flash.setFillStyle(0xffe97a, 0.72).setAlpha(0.72);
      this.tweens.add({
        targets: this.flash,
        alpha: 0,
        duration: 650,
        onComplete: () => this.flash.setFillStyle(0xffffff, 0),
      });
      this.checkWaveClear();
      return;
    }

    this.showDefeatChoices();
  }

  clearLastStandFx() {
    if (this.lastStandOverlay) {
      const overlay = this.lastStandOverlay;
      this.lastStandOverlay = null;
      this.tweens.add({ targets: overlay, alpha: 0, duration: 240, onComplete: () => overlay.destroy() });
    }
    if (this.lastStandText) {
      this.lastStandText.destroy();
      this.lastStandText = null;
    }
  }

  showDefeatChoices() {
    if (this.dying || this.over) return;
    this.dying = true;
    if (this.prepTimer) this.prepTimer.remove();
    if (this.spawnEvent) this.spawnEvent.remove();
    this.cameras.main.shake(500, 0.015);

    if (!this.revived) {
      // 广告复活（GDD §7）
      const layer = this.add.container(0, 0).setDepth(4000);
      layer.add(this.add.rectangle(W / 2, H / 2, W, H, 0x000000, 0.7).setInteractive());
      layer.add(this.add.rectangle(W / 2, 560, 560, 420, 0x1e2233).setStrokeStyle(3, 0x4a5578));
      layer.add(this.uiText(W / 2, 420, '💔 基地告急!', 44, '#ff7a7a').setOrigin(0.5));
      layer.add(this.uiText(W / 2, 490, `第 ${this.wave} 波`, 28, '#c9d2f0').setOrigin(0.5));
      layer.add(makeButton(this, W / 2, 590, 420, 80, '📺 复活 (回50%血+清场)', {
        bg: 0x6b4a86, stroke: 0xb07fe0, fontSize: 25,
        onClick: async () => {
          const ok = await Poki.rewardedBreak();
          if (!ok) return;
          layer.destroy();
          this.revive();
        },
      }));
      layer.add(makeButton(this, W / 2, 690, 420, 70, '结束本局', {
        bg: 0x51586e, fontSize: 24,
        onClick: () => { layer.destroy(); this.endRun(); },
      }));
    } else {
      this.endRun();
    }
  }

  revive() {
    this.revived = true;
    this.baseHp = Math.ceil(this.maxBase / 2);
    // 清场
    for (const e of [...this.enemies]) {
      this.burst(e.x, e.y, 0xffffff, 10, 1);
      e.dead = true;
      e.destroy();
    }
    this.enemies = [];
    this.spawnLeft = 0;
    this.dying = false;
    this.flash.setAlpha(0.7);
    this.tweens.add({ targets: this.flash, alpha: 0, duration: 600 });
    this.banner('复活!');
    this.updateUI();
    this.waveState = 'idle';
    this.endWave();
  }

  buildDeathAnalysis(S) {
    const wave = this.deathWave || this.wave;
    const candidates = [];
    const leakEntries = Object.entries(this.leakStats).sort((a, b) => b[1] - a[1]);
    const topLeak = leakEntries[0];

    if (topLeak && topLeak[1] >= 3) candidates.push(this.leakDiagnosis(topLeak[0], topLeak[1], wave));
    if (wave % 5 === 0 || this.leakStats.boss > 0) {
      candidates.push({
        key: 'boss_wave',
        text: `你死于第 ${wave} 波：Boss 波前囤好合成对，连锁共鸣一波爆发`,
      });
    }

    const expectedLv = this.expectedHighestLv(wave);
    if (this.highestLv < expectedLv) {
      candidates.push({
        key: 'low_highest_lv',
        text: `你死于第 ${wave} 波：最高塔只有 Lv${this.highestLv} → 少买多合，等级就是战力`,
        upgradeId: 'startLv',
      });
    }

    const freeSlots = this.slots.filter(s => !s.tower).length;
    if (freeSlots > 0 && this.gold >= towerCost(this.bought)) {
      candidates.push({
        key: 'idle_gold_slots',
        text: `你死于第 ${wave} 波：还空着 ${freeSlots} 个塔位 → 金币别攥着，塔位空一格就是防线漏一格`,
        upgradeId: 'startGold',
      });
    }

    candidates.push({
      key: 'fallback',
      text: `你死于第 ${wave} 波：试试解锁新元素，换个流派再战`,
      upgradeId: 'unlockPoison',
    });

    const diagnosis = this.pickDiagnosis(candidates, S);
    diagnosis.elements = this.elementSummary();
    return diagnosis;
  }

  leakDiagnosis(typeKey, count, wave) {
    const name = TYPE_CN[typeKey] || typeKey;
    if (typeKey === 'tank') {
      return {
        key: 'leak_tank',
        text: `你死于第 ${wave} 波：铁盾兵漏了 ${count} 只 → ☠毒塔无视护甲，专克铁罐头`,
        upgradeId: 'unlockPoison',
      };
    }
    if (typeKey === 'runner') {
      return {
        key: 'leak_runner',
        text: `你死于第 ${wave} 波：疾行者漏了 ${count} 只 → ❄冰塔减速，先稳住跑得快的`,
      };
    }
    if (typeKey === 'flyer') {
      return {
        key: 'leak_flyer',
        text: `你死于第 ${wave} 波：飞行兵漏了 ${count} 只 → ✨光塔和⚡电塔更适合拦截空中目标`,
        upgradeId: 'unlockLight',
      };
    }
    if (typeKey === 'splitter' || typeKey === 'mini') {
      return {
        key: 'leak_splitter',
        text: `你死于第 ${wave} 波：分裂怪漏了 ${count} 只 → 🔥火塔溅射能更快清掉小怪群`,
      };
    }
    return {
      key: `leak_${typeKey}`,
      text: `你死于第 ${wave} 波：${name}漏了 ${count} 只 → 少买多合，把主力塔等级抬起来`,
      upgradeId: 'startLv',
    };
  }

  expectedHighestLv(wave) {
    if (wave >= 30) return 7;
    if (wave >= 20) return 5;
    if (wave >= 10) return 3;
    if (wave >= 5) return 2;
    return 1;
  }

  pickDiagnosis(candidates, S) {
    const primary = candidates[0];
    const repeated = primary.key === S.lastDiagnosisKey ? (S.lastDiagnosisCount || 0) + 1 : 1;
    const chosen = repeated > 2 && candidates[1] ? candidates[1] : primary;
    S.lastDiagnosisCount = chosen.key === S.lastDiagnosisKey ? repeated : 1;
    S.lastDiagnosisKey = chosen.key;
    return { ...chosen };
  }

  elementSummary() {
    const counts = {};
    for (const t of this.towers) counts[t.elem] = (counts[t.elem] || 0) + 1;
    const parts = Object.entries(counts).map(([elem, count]) => `${ELEMENTS[elem].cn}×${count}`);
    return parts.length ? parts.join('  ') : '无塔';
  }

  async endRun() {
    if (this.over) return;
    this.over = true;
    Poki.gameplayStop();
    const S = this.S;
    const diagnosis = this.buildDeathAnalysis(S);
    const deathBonus = Math.floor(this.wave / DIAMOND.deathBonusPerWave);
    this.diamondsRun += deathBonus;
    S.diamonds += this.diamondsRun;
    const newBest = this.wave > S.best;
    if (newBest) S.best = this.wave;
    S.runs++;
    S.lastSeen = Date.now();
    writeSave(S);
    Sfx.gameOver();
    await Poki.commercialBreak();
    this.scene.start('Result', {
      wave: this.wave, kills: this.kills, dRun: this.diamondsRun, newBest, deathBonus, diagnosis,
    });
  }

  // ================= 主循环 =================
  update(time, delta) {
    if (this.over) return;
    if (this.evolutionChoiceOpen) return;
    let dts = (delta / 1000) * this.speedMult;
    if (this.lastStandActive) this.updateLastStand(delta / 1000);
    // 慢镜（按真实时间衰减）
    if (this.slowmoT > 0) {
      this.slowmoT -= delta / 1000;
      dts *= 0.3;
    }
    if (this.lastStandActive) dts *= 0.5;
    if (this.dying) return;

    // 敌人
    for (const e of [...this.enemies]) e.update(dts);

    // 光 Lv7 攻速 buff
    if (this.atkBuffT > 0) this.atkBuffT -= dts;
    else this.atkBuffMult = 1.3;
    let buff = this.atkBuffT > 0 ? (this.atkBuffMult || 1.3) : 1;
    if (this.lastStandActive) buff *= 6;

    // 塔开火
    for (const t of this.towers) {
      if (t.dragging) continue;
      t.tickCooldown(dts, buff);
      if (t.ready()) {
        const target = this.targetFor(t);
        if (target) this.fireTower(t, target);
      }
    }

    // 燃烧地面
    for (const z of this.burnZones) {
      z.t -= dts;
      z.tick -= dts;
      if (z.tick <= 0) {
        z.tick = 0.25;
        for (const e of [...this.enemies]) {
          if (!e.dead && !e.flying && Phaser.Math.Distance.Between(z.x, z.y, e.x, e.y) < z.radius) {
            e.takeDamage(z.dps * 0.25, { trueDmg: true, goldMult: z.goldMult });
          }
        }
      }
      if (z.t <= 0) z.img.destroy();
    }
    this.burnZones = this.burnZones.filter(z => z.t > 0);

    // Boss 血条
    const bosses = this.enemies.filter(e => e.boss);
    if (bosses.length) {
      const ratio = bosses.reduce((s, b) => s + Math.max(0, b.hp), 0) / bosses.reduce((s, b) => s + b.maxHp, 0);
      this.bossBarBg.setVisible(true);
      this.bossBar.setVisible(true).width = 600 * ratio;
    } else {
      this.bossBarBg.setVisible(false);
      this.bossBar.setVisible(false);
    }
  }
}
